subject = ["자바", "파이썬", "R"]

for x in subject:
    print(x)

team = {"디자이너", "프로그래머", "DB관리자"}
for x in team:
    print(x)

dic = {"apple":"사과", "banana":"바나나", "melon":"멜론"}
for x in dic:
    print(x) # 키만 출력됨