#인덱스가 없다
target = {1, 2, 3} #집합기호 "}" => 중복X

target.add(4)
print(target)

target.add(2)
print(target)