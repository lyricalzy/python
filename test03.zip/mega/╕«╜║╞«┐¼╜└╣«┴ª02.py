team = {"디자이너", "프로그래머", "DB관리자"}
print(team)
team.add("디자이너")
print(team)

ski = ["박스키", "송스키", "김스키", "정스키"]
print(ski)
del(ski[1])
print(ski)

phone = {"1번":"엄마", "2번":"아빠", "3번":"친구", "4번":"동생"}
print(phone)
print(phone.get("2번"))
print(len(phone))