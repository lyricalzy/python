dic = {"apple":"사과", "banana":"바나나", "melon":"멜론"}
print(dic)

print(dic.get("apple"))