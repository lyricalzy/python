import turtle

pen = turtle.Pen()
pen.left(90)
pen.forward(100)

i = 0
while i < 3:
    pen.right(90)
    pen.forward(100)
    i = i + 1