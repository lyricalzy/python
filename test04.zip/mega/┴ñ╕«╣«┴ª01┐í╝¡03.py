# 1
id = input("아이디: ")
name = input("이름: ")
print("아이디가", id + "인", name + "님이 로그인되었습니다.")

# 2
print("==========================")
num1 = int(input("숫자1: "))
num2 = int(input("숫자2: "))
print("-------------------------")
print("두 수의 합은", num1+num2)
print("두 수의 차은", num1-num2)
print("두 수의 곱은", num1*num2)
print("두 수의 나눗셈은", num1/num2)
print("나누고나서의 나머지는", num1%num2)

# 3
print("==========================")
name2 = input("이름: ")
age = int(input("현재 나이: "))
print(name2 + "님의 10년 후의 나이는", str(age+10) + "세입니다.")