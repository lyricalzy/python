print("hi")
print("hello")