# 주석처리 ctrl+/
# while True: #파이썬에서는 T와 F가 대문자
#     print("1시간 남았어요.")

# a = 10
# while a > 0:
#     print(a)
#     a = a - 1

b = 0
# 0부터 99까지 찍어보세요
# while b < 100:
#     print(b, end=" ")
#     b = b + 1

# 1부터 100까지 찍어보세요
# while b < 100:
#     b = b + 1
#     print(b, end=" ")

# 1부터 100까지 짝수만 찍어보세요
# while b < 100:
#     b = b + 1
#     if (b % 2 == 0):
#         print(b, end=" ")

# 0~99 중 3의 배수를 찍어보세요
# while b < 100:
#     b = b + 1
#     if (b % 3 == 0):
#         print(b, end=" ")

# 0~99 중 5의 배수의 개수를 구해보세요.
count = 0
while b < 99:
    b = b + 1
    if (b % 5 == 0):
        count = count + 1
print(count)

# 안녕히가세요 5번 프린트
# while b < 5:
#     print("안녕히가세요")
#     b = b + 1