from movie import price

price.info()
price.pay()