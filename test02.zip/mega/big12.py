data1 = input("로그인할 id를 입력>> ")
if data1 == "root":
    print("로그인 되었습니다.")
else:
    print("로그인되지 않았습니다")