def info():
    person = input("같이 볼 사람 이름 입력: ")
    relate = input("같이 볼 사람의 관계 입력: ")
    print(person + "는 나와", relate + "입니다.")
    
def pay():
    price = 10000
    person = int(input("같이 볼 사람 수 입력: "))
    print("지불할 금액은", str(price*person) + "원입니다.")