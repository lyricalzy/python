#계산기 세부 기능

def plus():
    print("더하기 기능 처리")
    a = int(input("첫번째 수 입력: "))
    b = int(input("두번째 수 입력: "))
    print("두수의 합은", a+b)

def minus():
    print("빼기 기능 처리")
    a = int(input("첫번째 수 입력: "))
    b = int(input("두번째 수 입력: "))
    print("두수의 차는", a-b)

def mul():
    print("곱하기 기능 처리")
    a = int(input("첫번째 수 입력: "))
    b = int(input("두번째 수 입력: "))
    print("두수의 곱은", a*b)