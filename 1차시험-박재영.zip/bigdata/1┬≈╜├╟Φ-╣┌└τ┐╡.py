from tkinter import *
import sys

customer = [""]  # 입금자
account = []  # 예금액


def menu01():  # 1. 입력
    print("------------1. 입력------------")
    customer[0] = input("입금자 이름: ")
    for i in range(0, 5):
        account.append(int(input("예금액 입력: ")))
    print("------------입력 완료------------")


def menu02():  # 2. 출력
    print("------------2. 출력------------")
    print("입금자:", customer[0])
    print("예금액:", account)
    print("------------출력 완료------------")


def menu03():  # 3. 수정
    print("------------3. 수정------------")
    check = input("입금자를 입력해주세요: ")
    while check != customer[0]: # 해당 고객이 있는지 확인
        print("해당 고객이 없습니다.")
        check = input("다시 입금자를 입력해주세요: ")
    change = int(input("수정할 예금액을 입력해주세요.: "))
    account[0] = change # 첫번째 예금액 수정
    print("------------수정 완료------------")


def menu04():  # 4. 정리
    print("------------4. 정리------------")
    sum = 0  # 예금액 총액
    for x in account:
        sum = sum + x # 예금액의 총액 계산
    print("입금액 합계: %d만원" % sum)
    print("입금액 평균: %d만원" % int(sum / 5))
    print("------------정리 완료------------")


def menu05():  # 5. 종료
    print("프로그램을 종료합니다.") # 종료하기 전에 종료메시지 출력
    sys.exit()


w = Tk() # 버튼을 표시할 창
w.geometry("450x400")
main_label = Label(w, text="은행 예금 관리 프로그램", font=("맑은고딕", 30), fg="blue")  # 라벨
main_label.pack()
button01 = Button(w, text="1. 입력", bg="blue", font=("새 굴림", 30), fg="white", command=menu01)  # 1번 버튼
button01.pack()
button02 = Button(w, text="2. 출력", bg="blue", font=("새 굴림", 30), fg="white", command=menu02)  # 2번 버튼
button02.pack()
button03 = Button(w, text="3. 수정", bg="blue", font=("새 굴림", 30), fg="white", command=menu03)  # 3번 버튼
button03.pack()
button04 = Button(w, text="4. 정리", bg="blue", font=("새 굴림", 30), fg="white", command=menu04)  # 4번 버튼
button04.pack()
button05 = Button(w, text="5. 종료", bg="blue", font=("새 굴림", 30), fg="red", command=menu05)  # 5번 버튼
button05.pack()
w.mainloop()
